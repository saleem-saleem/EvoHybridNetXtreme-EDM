"""Three-stage learning implementation with a never-touched test partition.

Stage-1 uses nested tuning inside outer folds for base-model OOF probabilities;
Stage-2's internal scores choose features (do NOT report as independent performance);
Stage-3 evaluates DE masks on training-partition validation rows.
"""
from dataclasses import dataclass
import copy
import warnings
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import accuracy_score, f1_score
from sklearn.calibration import CalibratedClassifierCV
from sklearn.exceptions import ConvergenceWarning
from scipy.optimize import differential_evolution
import optuna
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from .preprocess import build_preprocessor, fit_transform_train, screen_features
from .resampling import hybrid_resample

optuna.logging.set_verbosity(optuna.logging.WARNING)


def _models(seed):
    return {
        "RF": RandomForestClassifier(n_estimators=100, n_jobs=1, random_state=seed),
        "XGBoost": _xgb(seed),
        "SVM": SVC(kernel="rbf", C=1.0, gamma="scale"),
        "LR": LogisticRegression(max_iter=500, random_state=seed),
        "kNN": KNeighborsClassifier(n_neighbors=5),
    }


def _xgb(seed):
    try:
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=100, max_depth=3, learning_rate=.1,
                             tree_method="hist", random_state=seed, n_jobs=1)
    except ImportError:
        return HistGradientBoostingClassifier(max_iter=100, random_state=seed)


def _suggest(trial, name, template):
    if name == "RF":
        return {"n_estimators": trial.suggest_int("n_estimators", 80, 350),
                "max_depth": trial.suggest_int("max_depth", 3, 20)}
    if name == "XGBoost":
        return ({"n_estimators": trial.suggest_int("n_estimators", 80, 300),
                 "max_depth": trial.suggest_int("max_depth", 2, 8),
                 "learning_rate": trial.suggest_float("learning_rate", .02, .2, log=True)}
                if template.__class__.__name__ == "XGBClassifier" else
                {"max_iter": trial.suggest_int("max_iter", 80, 200),
                 "max_leaf_nodes": trial.suggest_int("max_leaf_nodes", 8, 31)})
    if name == "SVM":
        return {"C": trial.suggest_float("C", .01, 100, log=True),
                "gamma": trial.suggest_float("gamma", .0001, .1, log=True)}
    if name == "LR":
        return {"C": trial.suggest_float("C", .01, 10, log=True)}
    return {"n_neighbors": trial.suggest_int("n_neighbors", 2, 12)}


def _safe_folds(y, requested):
    return max(2, min(requested, int(np.bincount(np.asarray(y, dtype=int)).min())))


def _tune(name, template, X, y, cat_indices, *, trials, folds, seed):
    folds = _safe_folds(y, folds)
    cross = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    def objective(trial):
        params = _suggest(trial, name, template)
        scores = []
        for a, b in cross.split(X, y):
            model = clone(template).set_params(**params)
            Xfit, yfit, _ = hybrid_resample(X[a], y[a], method="smote",
                                            categorical_indices=cat_indices, seed=seed)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", ConvergenceWarning)
                    model.fit(Xfit, yfit)
                scores.append(f1_score(y[b], model.predict(X[b]), average="macro", zero_division=0))
            except Exception as exc:
                raise optuna.TrialPruned(str(exc)) from exc
        return float(np.mean(scores))
    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=max(1, trials), show_progress_bar=False)
    if not study.best_trials:
        raise RuntimeError(f"Unable to tune {name}; dataset may have insufficient valid samples")
    return clone(template).set_params(**study.best_params)


def _fit_calibrated(model, X, y, cat_indices, seed):
    Xfit, yfit, _ = hybrid_resample(X, y, method="smote", categorical_indices=cat_indices, seed=seed)
    # Each calibration fold trains independently. This is training-partition-only.
    fit = CalibratedClassifierCV(estimator=clone(model), method="sigmoid", cv=_safe_folds(yfit, 2))
    fit.fit(Xfit, yfit)
    return fit


def _soft_weights(acc, temperature=.5):
    logits = np.asarray(acc, dtype=float) / max(temperature, 1e-9)
    z = np.exp(logits - max(logits))
    return z / z.sum()


@dataclass
class Stage1Result:
    X_train: np.ndarray
    X_test: np.ndarray
    feature_names: list[str]
    categorical_indices: list[int]
    model_weights: dict
    risk_label: int
    oof_meta_prob: np.ndarray


def run_stage1(X_train, y_train, X_test, cats, risk_idx, *, seed=42, trials=5,
               outer_folds=3, inner_folds=2, temperature=.5):
    """OOF scoring, then independent full-train base models for held-out inference."""
    y_train = np.asarray(y_train, dtype=int)
    n_class = len(np.unique(y_train))
    if sorted(np.unique(y_train).tolist()) != list(range(n_class)):
        raise ValueError("Class encoding must be contiguous starting at 0")
    model_names = list(_models(seed))
    k = len(model_names)
    fold_count = _safe_folds(y_train, outer_folds)
    folds = StratifiedKFold(n_splits=fold_count, shuffle=True, random_state=seed)
    level0 = np.zeros((len(y_train), k * n_class))
    fold_accuracies = np.zeros((k, fold_count))
    for fold, (a, b) in enumerate(folds.split(X_train, y_train)):
        transformer, names, cat_idx = build_preprocessor(X_train, cats)
        A, B = fit_transform_train(transformer, X_train.iloc[a], X_train.iloc[b])
        keep = screen_features(A, y_train[a], seed=seed + fold)
        A, B = A[:, keep], B[:, keep]
        cats_fold = [p for p, old in enumerate(keep) if int(old) in cat_idx]
        for j, (name, template) in enumerate(_models(seed + fold).items()):
            tuned = _tune(name, template, A, y_train[a], cats_fold, trials=trials,
                          folds=inner_folds, seed=seed + fold)
            model = _fit_calibrated(tuned, A, y_train[a], cats_fold, seed + fold)
            proba = model.predict_proba(B)
            level0[b, j*n_class:(j+1)*n_class] = proba
            fold_accuracies[j, fold] = accuracy_score(y_train[b], np.argmax(proba, axis=1))
    weights = _soft_weights(fold_accuracies.mean(axis=1), temperature)
    weighted_oof = level0 * np.repeat(weights, n_class)[None, :]
    # Metalevel cross-fitting ensures its own row's outcome does not train its risk score.
    meta_oof = np.zeros((len(y_train), n_class))
    for a, b in folds.split(weighted_oof, y_train):
        meta = LogisticRegression(max_iter=800, random_state=seed)
        meta.fit(weighted_oof[a], y_train[a])
        meta_oof[b] = meta.predict_proba(weighted_oof[b])
    meta_final = LogisticRegression(max_iter=800, random_state=seed)
    meta_final.fit(weighted_oof, y_train)
    # Full train transforms fitted without looking at test labels.
    transformer, all_names, cat_idx = build_preprocessor(X_train, cats)
    A, B = fit_transform_train(transformer, X_train, X_test)
    keep = screen_features(A, y_train, seed=seed)
    A, B = A[:, keep], B[:, keep]
    cat_full = [p for p, old in enumerate(keep) if int(old) in cat_idx]
    names = [all_names[i] for i in keep]
    test_level0 = np.zeros((len(B), k*n_class))
    for j, (name, template) in enumerate(_models(seed).items()):
        tuned = _tune(name, template, A, y_train, cat_full, trials=trials,
                      folds=inner_folds, seed=seed)
        model = _fit_calibrated(tuned, A, y_train, cat_full, seed)
        test_level0[:, j*n_class:(j+1)*n_class] = model.predict_proba(B)
    test_risk_probs = meta_final.predict_proba(test_level0 * np.repeat(weights, n_class)[None, :])
    # Explicitly designated class only: cannot silently call 'Enrolled' at-risk.
    atrain, atest = meta_oof[:, [risk_idx]], test_risk_probs[:, [risk_idx]]
    all_train, all_test = np.column_stack((A, atrain)), np.column_stack((B, atest))
    return Stage1Result(all_train, all_test, names + ["oof_risk_score"],
                        cat_full, dict(zip(model_names, map(float, weights))),
                        risk_idx, meta_oof)


@dataclass
class Stage2Result:
    selected: np.ndarray
    cv_macro_f1: float
    reference_name: str
    reference_model: object
    class_counts: dict


def select_features(X, y, cats, *, seed=42, method="hybrid", smote_fraction=.60,
                    folds=3, min_features=2, max_rounds=8, step=1):
    """Heuristic RFE on training only; CV scores are for selection, not reported as unbiased results."""
    y = np.asarray(y, dtype=int)
    folds = _safe_folds(y, folds)
    cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    candidates = np.arange(X.shape[1], dtype=int)
    min_features = max(1, min(min_features, len(candidates)))
    best = candidates.copy()
    best_score = -1.
    for iteration in range(max_rounds + 1):
        current_cats = [p for p, original in enumerate(candidates) if int(original) in cats]
        scores = []
        for a, b in cv.split(X, y):
            Xa, ya, _ = hybrid_resample(X[a][:, candidates], y[a], method=method,
                                       smote_fraction=smote_fraction,
                                       categorical_indices=current_cats,
                                       seed=seed + iteration)
            model = RandomForestClassifier(n_estimators=80, random_state=seed, n_jobs=1)
            model.fit(Xa, ya)
            scores.append(f1_score(y[b], model.predict(X[b][:, candidates]), average="macro", zero_division=0))
        score = float(np.mean(scores))
        if score > best_score + 1e-8 or (abs(score - best_score) <= 1e-8 and len(candidates) < len(best)):
            best_score, best = score, candidates.copy()
        if len(candidates) <= min_features or iteration >= max_rounds:
            break
        full_resampled, yr, _ = hybrid_resample(X[:, candidates], y, method=method,
                                                smote_fraction=smote_fraction,
                                                categorical_indices=current_cats,
                                                seed=seed + iteration)
        rf = RandomForestClassifier(n_estimators=80, random_state=seed, n_jobs=1).fit(full_resampled, yr)
        importance = rf.feature_importances_
        drop = np.argsort(importance)[:min(step, len(candidates) - min_features)]
        candidates = np.delete(candidates, drop)
    return best, best_score


def run_stage2(X, y, cat_indices, *, seed=42, method="hybrid",
               smote_fraction=.6, folds=3, max_rounds=8):
    selected, score = select_features(X, y, cat_indices, seed=seed, method=method,
                                      smote_fraction=smote_fraction, folds=folds,
                                      max_rounds=max_rounds)
    selcats = [j for j, i in enumerate(selected) if int(i) in cat_indices]
    Xa, ya, sampling = hybrid_resample(X[:, selected], y, method=method,
                                      smote_fraction=smote_fraction,
                                      categorical_indices=selcats, seed=seed)
    references = {"LR": LogisticRegression(max_iter=800, random_state=seed),
                  "RF": RandomForestClassifier(n_estimators=150, random_state=seed, n_jobs=1),
                  "XGBoost": _xgb(seed), "SVM": SVC(kernel="rbf", probability=True, random_state=seed)}
    scores = {}
    # Classifier selection is based on inner cross-validation of original samples.
    cv = StratifiedKFold(n_splits=_safe_folds(y, folds), shuffle=True, random_state=seed)
    for key, estimator in references.items():
        fold_scores = []
        for a, b in cv.split(X, y):
            xb, yb, _ = hybrid_resample(X[a][:, selected], y[a], method=method,
                                       smote_fraction=smote_fraction,
                                       categorical_indices=selcats, seed=seed)
            m = clone(estimator).fit(xb, yb)
            fold_scores.append(f1_score(y[b], m.predict(X[b][:, selected]),
                                        average="macro", zero_division=0))
        scores[key] = float(np.mean(fold_scores))
    best_name = max(scores, key=scores.get)
    ref_model = clone(references[best_name]).fit(Xa, ya)
    return Stage2Result(selected, score, best_name, ref_model, sampling)


class CNNLSTM(nn.Module):
    def __init__(self, num_classes, filters=32, hidden=32):
        super().__init__()
        self.conv = nn.Conv1d(1, filters, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(2)
        self.rnn = nn.LSTM(input_size=filters, hidden_size=hidden, batch_first=True)
        self.dropout = nn.Dropout(.3)
        self.final = nn.Linear(hidden, num_classes)

    def forward(self, x):
        z = torch.relu(self.conv(x.unsqueeze(1)))
        if z.shape[-1] >= 2:
            z = self.pool(z)
        z = z.transpose(1, 2)
        _, (h, _) = self.rnn(z)
        return self.final(self.dropout(h[-1]))


def _train_network(Xtrain, ytrain, Xval, yval, *, n_classes, epochs, seed=42,
                   filters=32, patience=4, learning_rate=.001):
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    model = CNNLSTM(n_classes, filters=filters)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    lossfun = nn.CrossEntropyLoss()
    train_set = TensorDataset(torch.tensor(np.asarray(Xtrain), dtype=torch.float32),
                              torch.tensor(np.asarray(ytrain), dtype=torch.long))
    loader = DataLoader(train_set, batch_size=32, shuffle=True,
                        generator=torch.Generator().manual_seed(seed))
    xv = torch.tensor(np.asarray(Xval), dtype=torch.float32)
    yv = torch.tensor(np.asarray(yval), dtype=torch.long)
    best_loss, state, stale = float("inf"), None, 0
    for _ in range(epochs):
        model.train()
        for xb, yb in loader:
            optimizer.zero_grad()
            loss = lossfun(model(xb), yb)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            val_loss = float(lossfun(model(xv), yv).item())
        if val_loss + 1e-5 < best_loss:
            best_loss, state, stale = val_loss, copy.deepcopy(model.state_dict()), 0
        else:
            stale += 1
            if stale >= patience:
                break
    model.load_state_dict(state)
    return model


def _predict_network(model, X):
    model.eval()
    with torch.no_grad():
        logits = model(torch.tensor(np.asarray(X), dtype=torch.float32))
        return torch.softmax(logits, 1).numpy()


@dataclass
class Stage3Result:
    selected_in_stage2: np.ndarray
    predictions: np.ndarray
    probabilities: np.ndarray
    de_evaluations: int
    validation_objective: str


def run_stage3(X, y, Xtest, cat_indices, *, seed=42, sampling="hybrid", smote_fraction=.60,
               use_de=True, de_generations=2, de_popsize=3, de_epochs=5,
               final_epochs=30, de_objective="accuracy", filters=32):
    """Only X and y from training; Xtest never drives mask choice or early stopping."""
    X, y, Xtest = np.asarray(X), np.asarray(y, dtype=int), np.asarray(Xtest)
    if de_objective not in {"accuracy", "macro_f1"}:
        raise ValueError("Unsupported DE fitness")
    a, b = train_test_split(np.arange(len(y)), test_size=.2, random_state=seed, stratify=y)
    mask_cache = {}
    n_calls = 0
    def evaluate(vector):
        nonlocal n_calls
        bits = np.asarray(vector) >= .5
        if not bits.any():
            return 1.0
        key = tuple(bits.tolist())
        if key in mask_cache:
            return mask_cache[key]
        indices = np.flatnonzero(bits)
        subcats = [j for j, i in enumerate(indices) if int(i) in cat_indices]
        xf, yf, _ = hybrid_resample(X[a][:, indices], y[a], method=sampling,
                                    categorical_indices=subcats, smote_fraction=smote_fraction, seed=seed)
        m = _train_network(xf, yf, X[b][:, indices], y[b], n_classes=len(np.unique(y)),
                           epochs=de_epochs, seed=seed, filters=filters)
        yp = _predict_network(m, X[b][:, indices]).argmax(axis=1)
        score = (accuracy_score(y[b], yp) if de_objective == "accuracy" else
                 f1_score(y[b], yp, average="macro", zero_division=0))
        # Tiny size penalty implements tie preference for fewer features.
        value = 1 - float(score) + 1e-6 * bits.sum() / len(bits)
        mask_cache[key] = value
        n_calls += 1
        return value
    if use_de and X.shape[1] > 1:
        result = differential_evolution(evaluate, [(0., 1.)] * X.shape[1],
             strategy="rand1bin", popsize=max(2, de_popsize), maxiter=max(1, de_generations),
             polish=False, seed=seed, tol=0., disp=False)
        # Search best evaluated binary mask: continuous best can map to an evaluated mask.
        best_mask = np.array(min(mask_cache, key=mask_cache.get), dtype=bool)
        assert best_mask.any()
    else:
        best_mask = np.ones(X.shape[1], dtype=bool)
    picked = np.flatnonzero(best_mask)
    cats_picked = [j for j, i in enumerate(picked) if int(i) in cat_indices]
    xf, yf, _ = hybrid_resample(X[a][:, picked], y[a], method=sampling,
                                categorical_indices=cats_picked, smote_fraction=smote_fraction, seed=seed)
    model = _train_network(xf, yf, X[b][:, picked], y[b],
                           n_classes=len(np.unique(y)), epochs=final_epochs,
                           seed=seed, filters=filters)
    probabilities = _predict_network(model, Xtest[:, picked])
    return Stage3Result(picked, probabilities.argmax(axis=1), probabilities,
                        n_calls, de_objective)
