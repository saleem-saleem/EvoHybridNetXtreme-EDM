"""Dataset loading and explicit target semantics.

UCI dataset metadata is authoritative, not the manuscript's derived binary counts.
Never guess the target for a dataset that does not define one.
"""
from dataclasses import dataclass
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

UCI_DATASETS = {"d3": 582, "d4": 467, "d5": 856, "d6": 697}

# D6 has nominal integer codes; avoid silently treating every code as a continuous value.
D6_CATEGORICAL = (
    "Marital status", "Application mode", "Course", "Daytime/evening attendance",
    "Previous qualification", "Nacionality", "Mother's qualification",
    "Father's qualification", "Mother's occupation", "Father's occupation",
    "Displaced", "Educational special needs", "Debtor", "Tuition fees up to date",
    "Gender", "Scholarship holder", "International",
)

@dataclass
class DataBundle:
    X: pd.DataFrame
    y: np.ndarray
    dataset: str
    label_mapping: dict
    categorical_columns: list[str]
    positive_label: str | None
    note: str


def _synthetic(which: str) -> tuple[pd.DataFrame, pd.Series]:
    cfg = {"d1": (500, 2, .72, 42), "d2": (1000, 3, .84, 43)}[which]
    n, d, majority, seed = cfg
    X, y = make_classification(
        n_samples=n, n_features=d, n_informative=d, n_redundant=0,
        n_repeated=0, n_classes=2, n_clusters_per_class=2, weights=[majority, 1 - majority],
        class_sep=1.0, flip_y=0, random_state=seed)
    return pd.DataFrame(X, columns=[f"feature_{i+1}" for i in range(d)]), pd.Series(y, name="outcome")


def load_data(name: str, *, csv_path: str | None = None, target_column: str | None = None,
              mode: str = "original", positive_label: str | None = None,
              categorical_columns: list[str] | None = None,
              binary_positive_values: list[str] | None = None) -> DataBundle:
    name = name.lower()
    if csv_path:
        frame = pd.read_csv(csv_path)
        if not target_column or target_column not in frame.columns:
            raise ValueError("CSV requires --target-column naming an existing column")
        X, target = frame.drop(columns=[target_column]), frame[target_column]
        note = f"User-supplied CSV: {csv_path}"
    elif name in ("d1", "d2"):
        X, target = _synthetic(name)
        note = "Synthetic scikit-learn make_classification; NOT records of actual learners."
    elif name in UCI_DATASETS:
        try:
            from ucimlrepo import fetch_ucirepo
        except ImportError as exc:
            raise RuntimeError("Install ucimlrepo or supply a local --csv") from exc
        obj = fetch_ucirepo(id=UCI_DATASETS[name])
        X = obj.data.features.copy()
        targets = obj.data.targets
        if target_column:
            full = obj.data.original
            if full is None or target_column not in full.columns:
                raise ValueError(f"Target column {target_column!r} was not found in source. Inspect UCI metadata.")
            target = full[target_column]
            X = full.drop(columns=[target_column])
        elif targets is None or targets.shape[1] == 0:
            raise ValueError(f"UCI {UCI_DATASETS[name]} has no unambiguous target exposed. "
                             "Pass --target-column after verifying the dataset's target definition.")
        elif targets.shape[1] != 1:
            raise ValueError("Multiple target columns; specify --target-column explicitly")
        else:
            target = targets.iloc[:, 0]
        note = f"UCI repository ID {UCI_DATASETS[name]}. Check availability timing of each feature."
    else:
        raise ValueError("Dataset must be d1..d6; custom CSV: pass --csv with any dataset label")

    X = X.reset_index(drop=True).copy()
    target = pd.Series(target).reset_index(drop=True)
    valid = ~target.isna()
    X, target = X.loc[valid].reset_index(drop=True), target.loc[valid].reset_index(drop=True)
    if X.empty:
        raise ValueError("No labeled examples")
    # Drop explicit identifiers if present; ID is never a learning feature.
    for col in list(X.columns):
        if str(col).strip().lower() in {"student id", "student_id", "id"}:
            X.drop(columns=[col], inplace=True)
    raw = target.astype(str).str.strip()
    if binary_positive_values:
        if mode != "original":
            raise ValueError("--binary-positive-values is only valid in original mode")
        posset = {str(v).strip() for v in binary_positive_values}
        unknown = posset - set(raw.unique())
        if unknown:
            raise ValueError(f"Declared positive values not found in target: {sorted(unknown)}")
        y = raw.isin(posset).to_numpy(dtype=int)
        mapping = {"all_other_outcomes": 0, "positive_" + "+".join(sorted(posset)): 1}
        risk = "positive_" + "+".join(sorted(posset))
        note += f" Explicit binary target: {sorted(posset)} vs every other class."
    elif mode == "dropout-vs-rest":
        if not (raw.str.lower() == "dropout").any():
            raise ValueError("dropout-vs-rest requires a literal 'Dropout' label")
        y = (raw.str.lower() == "dropout").to_numpy(dtype=int)
        mapping = {"not_Dropout_including_Enrolled": 0, "Dropout": 1}
        risk = "Dropout"
        note += " Binary outcome includes Enrolled in NOT-dropout; this is not proven eventual success."
    elif mode == "dropout-vs-graduate":
        use = raw.str.lower().isin(["dropout", "graduate"])
        X, raw = X.loc[use].reset_index(drop=True), raw.loc[use].reset_index(drop=True)
        y = (raw.str.lower() == "dropout").to_numpy(dtype=int)
        mapping = {"Graduate": 0, "Dropout": 1}
        risk = "Dropout"
        note += " Enrolled samples removed; changed sample size from original 4424."
    elif mode == "original":
        classes = sorted(raw.unique().tolist())
        if len(classes) < 2:
            raise ValueError("Need >=2 observed classes")
        if positive_label is not None:
            if positive_label not in classes:
                raise ValueError(f"positive label {positive_label!r} not in {classes}")
            # Explicitly make risk = class 1 in binary mode.
            if len(classes) == 2:
                classes = [c for c in classes if c != positive_label] + [positive_label]
        y = np.array([classes.index(v) for v in raw], dtype=int)
        mapping = {c: i for i, c in enumerate(classes)}
        risk = positive_label
        if len(classes) > 2 and risk is None:
            note += " Multiclass classification; no single academically at-risk class defined."
        if len(classes) == 2 and risk is None:
            note += " Binary classes encoded alphabetically; class 1 is not automatically academic risk."
    else:
        raise ValueError("mode must be original, dropout-vs-rest or dropout-vs-graduate")

    if categorical_columns is None:
        cats = X.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
        if name == "d6":
            cats = sorted(set(cats) | (set(D6_CATEGORICAL) & set(X.columns)))
        if name == "d5":
            cats = list(X.columns)  # documented coded questionnaire categories; ordinal codes
    else:
        cats = categorical_columns
    missing = sorted(set(cats) - set(X.columns))
    if missing:
        raise ValueError(f"Categorical columns not in dataset: {missing}")
    if len(np.unique(y)) < 2 or min(np.bincount(y)) < 2:
        raise ValueError("Too few samples per class to form a training/test split")
    return DataBundle(X=X, y=y, dataset=name, label_mapping=mapping,
                      categorical_columns=list(cats), positive_label=risk, note=note)


def holdout_split(data: DataBundle, seed: int, test_size: float = 0.2):
    return train_test_split(np.arange(len(data.y)), test_size=test_size,
                            stratify=data.y, random_state=seed)
