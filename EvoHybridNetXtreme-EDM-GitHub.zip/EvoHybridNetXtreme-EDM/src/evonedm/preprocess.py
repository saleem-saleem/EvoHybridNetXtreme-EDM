"""Train-only transformations; do not fit encoders or label-informed filters on test data."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler, OrdinalEncoder
from sklearn.feature_selection import mutual_info_classif
from sklearn.pipeline import Pipeline


def build_preprocessor(X: pd.DataFrame, categorical_columns: list[str]):
    cats = [c for c in X.columns if c in categorical_columns]
    nums = [c for c in X.columns if c not in cats]
    transformers = []
    if nums:
        transformers.append(("numeric", Pipeline([
            ("impute", SimpleImputer(strategy="median", add_indicator=False)),
            ("scale", MinMaxScaler(clip=True))]), nums))
    if cats:
        transformers.append(("categorical", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("encode", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)),
        ]), cats))
    transformer = ColumnTransformer(transformers, sparse_threshold=0)
    return transformer, nums + cats, list(range(len(nums), len(nums) + len(cats)))


def fit_transform_train(preprocessor, X_train, X_other):
    # Stage-1 fit on local training fold; never on held-out rows.
    A = np.asarray(preprocessor.fit_transform(X_train), dtype=float)
    B = np.asarray(preprocessor.transform(X_other), dtype=float)
    return A, B


def screen_features(A: np.ndarray, y: np.ndarray, *, min_var=1e-3, min_mi=0.01,
                    max_corr=.80, seed=42):
    """Manuscript-style variance/MI/correlation screening fitted on training rows only.

    MI for ordinal-encoded categories requires categorical indices; using a numeric
    MI estimator for mixed coded features is an approximation. No label-based
    information from validation/test rows is ever used.
    """
    if A.shape[1] < 1:
        raise ValueError("No features")
    ids = np.flatnonzero(np.var(A, axis=0) >= min_var)
    if not len(ids):
        ids = np.array([int(np.argmax(np.var(A, axis=0)))])
    mi = mutual_info_classif(A[:, ids], y, random_state=seed)
    surviving = ids[mi >= min_mi]
    if not len(surviving):
        surviving = np.array([ids[int(np.argmax(mi))]])
    mi_lookup = {int(idx): float(value) for idx, value in zip(ids, mi)}
    chosen = []
    for idx in sorted(surviving, key=lambda k: -mi_lookup[int(k)]):
        v = A[:, int(idx)]
        if all(abs(np.corrcoef(v, A[:, j])[0, 1]) < max_corr for j in chosen):
            chosen.append(int(idx))
    return np.asarray(sorted(chosen), dtype=int)
