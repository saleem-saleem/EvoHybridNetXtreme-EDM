"""Command-line study runner: write measured outcomes; do not recreate manuscript values."""
import argparse
import json
import platform
from pathlib import Path
import random
import warnings
import numpy as np
import pandas as pd
import torch
import sklearn
from .data import load_data, holdout_split
from .stages import run_stage1, run_stage2, run_stage3
from .metrics import calculate_metrics
from .benchmarks import evaluate_baselines, evaluate_tabnet


def _jsonable(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(f"Not JSON serializable: {type(obj)}")


def _save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, default=_jsonable), encoding="utf-8")


def _risk_index(bundle):
    if bundle.dataset in {"d1", "d2"} and bundle.positive_label is None:
        return bundle.label_mapping["1"]
    if bundle.positive_label is not None:
        return bundle.label_mapping.get(bundle.positive_label, 1)
    raise ValueError("Academic risk is not defined. Supply --positive-label (original mode), "
                     "or --target-mode dropout-vs-rest / dropout-vs-graduate for D6. "
                     "Never infer academic risk from class frequency.")


def _do_ablation(args, stage1, y_train, X_test, y_test, risk_idx, name, method, include_risk, use_de, is_classical):
    train, test = stage1.X_train, stage1.X_test
    names = stage1.feature_names
    cats = stage1.categorical_indices
    if not include_risk:
        train, test = train[:, :-1], test[:, :-1]
    s2 = run_stage2(train, y_train, cats, seed=args.seed, method=method,
                    folds=args.cv_folds, max_rounds=args.rfe_rounds)
    idx = s2.selected
    cat_sel = [j for j, i in enumerate(idx) if int(i) in cats]
    if is_classical:
        model = s2.reference_model
        proba = model.predict_proba(test[:, idx])
        pred = proba.argmax(1)
        eval_count = 0
    else:
        s3 = run_stage3(train[:, idx], y_train, test[:, idx], cat_sel,
                        seed=args.seed, sampling=method, use_de=use_de,
                        de_generations=args.de_generations, de_popsize=args.de_popsize,
                        de_epochs=args.de_epochs, final_epochs=args.epochs,
                        de_objective=args.de_objective)
        pred, proba, eval_count = s3.predictions, s3.probabilities, s3.de_evaluations
    metrics, _ = calculate_metrics(y_test, pred, proba, risk_idx)
    return {"variant": name, "stage2_features": len(idx), "de_evaluations": eval_count, **metrics}


def build_parser():
    parser = argparse.ArgumentParser(description="Run real, leakage-aware student outcome experiments")
    parser.add_argument("--dataset", default="d1", help="d1...d6 (d1,d2 are synthetic); arbitrary name for --csv")
    parser.add_argument("--csv", help="local CSV alternative to UCI fetch")
    parser.add_argument("--target-column", help="mandatory for CSV; UCI D4 may need a justified target")
    parser.add_argument("--target-mode", choices=["original", "dropout-vs-rest", "dropout-vs-graduate"], default="original")
    parser.add_argument("--positive-label", help="literal outcome that represents at-risk in original mode")
    parser.add_argument("--binary-positive-values", default="", help="comma-separated raw labels converted to class 1, everything else class 0 (explicit target mapping)")
    parser.add_argument("--categorical-columns", default="", help="comma-separated override for numeric coded categories")
    parser.add_argument("--output", default="results/d1")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--test-size", type=float, default=.2)
    parser.add_argument("--trials", type=int, default=5)
    parser.add_argument("--cv-folds", type=int, default=3)
    parser.add_argument("--inner-folds", type=int, default=2)
    parser.add_argument("--rfe-rounds", type=int, default=8)
    parser.add_argument("--de-generations", type=int, default=2)
    parser.add_argument("--de-popsize", type=int, default=3)
    parser.add_argument("--de-epochs", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--de-objective", choices=["accuracy", "macro_f1"], default="accuracy")
    parser.add_argument("--with-ablations", action="store_true")
    parser.add_argument("--skip-baselines", action="store_true")
    parser.add_argument("--fast", action="store_true", help="small computational budgets for a functional smoke run")
    return parser


def run(args):
    if args.fast:
        args.trials, args.cv_folds = 1, 2
        args.inner_folds, args.rfe_rounds = 2, 2
        args.de_generations, args.de_popsize, args.de_epochs, args.epochs = 1, 2, 2, 6
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(1)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    custom_cats = [c.strip() for c in args.categorical_columns.split(",") if c.strip()] or None
    bundle = load_data(args.dataset, csv_path=args.csv, target_column=args.target_column,
                       mode=args.target_mode, positive_label=args.positive_label,
                       categorical_columns=custom_cats,
                       binary_positive_values=[x.strip() for x in args.binary_positive_values.split(",") if x.strip()] or None)
    risk_idx = _risk_index(bundle)
    idx_train, idx_test = holdout_split(bundle, args.seed, args.test_size)
    X_train, X_test = bundle.X.iloc[idx_train], bundle.X.iloc[idx_test]
    y_train, y_test = bundle.y[idx_train], bundle.y[idx_test]
    data_info = {
        "dataset": bundle.dataset, "n_total": len(bundle.y), "raw_features": bundle.X.shape[1],
        "label_mapping": bundle.label_mapping, "risk_index": risk_idx,
        "class_counts_original": {str(k): int(v) for k, v in zip(*np.unique(bundle.y, return_counts=True))},
        "n_train": len(idx_train), "n_test": len(idx_test),
        "test_original_row_indices": idx_test.tolist(),
        "note": bundle.note, "categorical_columns": bundle.categorical_columns,
        "not_a_reproduction_of_manuscript_scores": True,
    }
    _save_json(output / "dataset_manifest.json", data_info)
    print(f"Data: {bundle.dataset}; {len(y_train)} train, {len(y_test)} test; positive/risk index {risk_idx}", flush=True)
    s1 = run_stage1(X_train, y_train, X_test, bundle.categorical_columns, risk_idx,
                    trials=args.trials, outer_folds=args.cv_folds,
                    inner_folds=args.inner_folds, seed=args.seed)
    s2 = run_stage2(s1.X_train, y_train, s1.categorical_indices,
                    seed=args.seed, folds=args.cv_folds, max_rounds=args.rfe_rounds)
    cat_sel = [j for j, i in enumerate(s2.selected) if int(i) in s1.categorical_indices]
    s3 = run_stage3(s1.X_train[:, s2.selected], y_train, s1.X_test[:, s2.selected], cat_sel,
                    seed=args.seed, de_generations=args.de_generations,
                    de_popsize=args.de_popsize, de_epochs=args.de_epochs,
                    final_epochs=args.epochs, de_objective=args.de_objective)
    metrics, cm = calculate_metrics(y_test, s3.predictions, s3.probabilities, risk_idx)
    print("Measured held-out performance:", metrics, flush=True)
    _save_json(output / "proposed_metrics.json", metrics)
    pd.DataFrame(cm).to_csv(output / "confusion_matrix.csv", index=False)
    pd.DataFrame({"row_id": idx_test, "y_true": y_test,
                  "y_pred": s3.predictions,
                  **{f"p_class_{i}": s3.probabilities[:, i] for i in range(s3.probabilities.shape[1])}}).to_csv(
                      output / "test_predictions.csv", index=False)
    final_features = [s1.feature_names[s2.selected[p]] for p in s3.selected_in_stage2]
    _save_json(output / "model_details.json", {
        "stage1_weights_not_bayesian_posterior": s1.model_weights,
        "stage2_selected_features": [s1.feature_names[i] for i in s2.selected],
        "stage2_internal_cv_macro_f1_for_model_selection_only": s2.cv_macro_f1,
        "stage2_reference_model": s2.reference_name,
        "stage2_synthetic_counts": s2.class_counts,
        "final_features": final_features, "de_unique_fitness_evaluations": s3.de_evaluations,
        "de_fitness": s3.validation_objective,
        "stage3_note": "Non-temporal tabular columns treated as a fixed pseudo-sequence; this does not establish temporal learning.",
    })
    rows = [{"model": "Proposed three-stage", **metrics}]
    if not args.skip_baselines:
        base, _, _ = evaluate_baselines(s1.X_train[:, :-1], y_train,
                      s1.X_test[:, :-1], y_test, s1.categorical_indices,
                      risk_idx, seed=args.seed, fast=args.fast)
        rows.extend(base)
        if not args.fast:
            rows.append(evaluate_tabnet(s1.X_train[:, :-1], y_train,
                         s1.X_test[:, :-1], y_test, risk_idx, args.seed))
    pd.DataFrame(rows).to_csv(output / "baseline_comparison.csv", index=False)
    if args.with_ablations:
        variants = [
            ("without_risk_score", "hybrid", False, True, False),
            ("smote_only", "smote", True, True, False),
            ("adasyn_only", "adasyn", True, True, False),
            ("no_resampling", "none", True, True, False),
            ("without_DE", "hybrid", True, False, False),
            ("stage2_classical_only", "hybrid", True, False, True),
        ]
        ablations = [{"variant": "complete_framework", "stage2_features": len(s2.selected),
                      "de_evaluations": s3.de_evaluations, **metrics}]
        for name, method, include_risk, use_de, classical in variants:
            print("Ablation:", name, flush=True)
            try:
                ablations.append(_do_ablation(args, s1, y_train, s1.X_test, y_test,
                                              risk_idx, name, method, include_risk,
                                              use_de, classical))
            except Exception as exc:
                ablations.append({"variant": name, "error": str(exc)})
        pd.DataFrame(ablations).to_csv(output / "ablation.csv", index=False)
    _save_json(output / "run_config.json", vars(args))
    _save_json(output / "environment.json", {
        "python": platform.python_version(), "platform": platform.platform(),
        "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__,
        "torch": torch.__version__, "seed": args.seed,
    })
    print(f"Results saved to {output.resolve()}", flush=True)
    return metrics


def main():
    args = build_parser().parse_args()
    run(args)

if __name__ == "__main__":
    main()
