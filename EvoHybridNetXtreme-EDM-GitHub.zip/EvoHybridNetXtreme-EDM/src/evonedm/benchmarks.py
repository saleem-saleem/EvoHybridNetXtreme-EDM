"""Baselines on identical held-out indices; no score hardcoding.

Baselines are illustrative defaults, not hyperparameter-budget-matched research claims.
"""
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression
from .metrics import calculate_metrics
from .resampling import hybrid_resample


def get_baselines(seed):
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=1),
        "MLP": MLPClassifier(hidden_layer_sizes=(64,32), early_stopping=True,
                             max_iter=150, random_state=seed),
    }
    try:
        from xgboost import XGBClassifier
        xgb = XGBClassifier(n_estimators=150, max_depth=4, tree_method="hist",
                            n_jobs=1, random_state=seed)
        models["XGBoost"] = xgb
        models["XGBoost + SMOTE"] = clone(xgb)
    except ImportError:
        models["HistGradientBoosting (fallback)"] = HistGradientBoostingClassifier(random_state=seed)
    try:
        from lightgbm import LGBMClassifier
        models["LightGBM"] = LGBMClassifier(n_estimators=150, verbosity=-1, n_jobs=1, random_state=seed)
    except ImportError:
        pass
    try:
        from catboost import CatBoostClassifier
        models["CatBoost"] = CatBoostClassifier(iterations=150, verbose=False,
                                                 thread_count=1, random_seed=seed)
    except ImportError:
        pass
    return models


def evaluate_baselines(X_train, y_train, X_test, y_test, cat_indices, risk_idx, seed, fast=False):
    rows, confusions, probabilities = [], {}, {}
    for name, model in get_baselines(seed).items():
        if fast and name not in {"Logistic Regression", "Random Forest", "XGBoost + SMOTE"}:
            continue
        if name == "XGBoost + SMOTE":
            Xfit, yfit, _ = hybrid_resample(X_train, y_train, method="smote",
                                            categorical_indices=cat_indices, seed=seed)
        else:
            Xfit, yfit = X_train, y_train
        try:
            model.fit(Xfit, yfit)
            proba = model.predict_proba(X_test)
            pred = proba.argmax(axis=1)
            values, cm = calculate_metrics(y_test, pred, proba, risk_idx=risk_idx)
            rows.append({"model": name, **values})
            confusions[name] = cm
            probabilities[name] = proba
        except Exception as exc:
            rows.append({"model": name, "skipped_reason": str(exc)})
    return rows, confusions, probabilities


def evaluate_tabnet(X_train, y_train, X_test, y_test, risk_idx, seed, fast=False):
    if fast:
        return {"model": "TabNet", "skipped_reason": "--fast option"}
    try:
        import numpy as np
        import torch
        from pytorch_tabnet.tab_model import TabNetClassifier
        torch.manual_seed(seed)
        model = TabNetClassifier(seed=seed, verbose=0)
        model.fit(np.asarray(X_train, dtype="float32"), np.asarray(y_train),
                  max_epochs=30, patience=5, batch_size=128, virtual_batch_size=32)
        probs = model.predict_proba(np.asarray(X_test, dtype="float32"))
        values, _ = calculate_metrics(y_test, probs.argmax(axis=1), probs, risk_idx)
        return {"model": "TabNet", **values}
    except ImportError:
        return {"model": "TabNet", "skipped_reason": "Install pytorch-tabnet optional extra"}
    except Exception as exc:
        return {"model": "TabNet", "skipped_reason": str(exc)}
