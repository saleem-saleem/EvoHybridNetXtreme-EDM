"""Class-conditional hybrid generation that keeps nominal attributes valid.

Explicit approximation of manuscript's SMOTE/ADASYN mixture. For categorical
features, parents donate categorical values; numeric features are interpolated.
This is NOT identical to stock imbalanced-learn SMOTE+ADASYN sequential calls.
"""
import numpy as np
from sklearn.neighbors import NearestNeighbors


def hybrid_resample(X, y, *, method="hybrid", smote_fraction=.60,
                    categorical_indices=(), seed=42, k=5):
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    if method == "none":
        return X.copy(), y.copy(), {"synthetic": 0, "by_class": {}}
    if method not in {"hybrid", "smote", "adasyn"}:
        raise ValueError("method must be none/hybrid/smote/adasyn")
    if not 0 <= smote_fraction <= 1:
        raise ValueError("smote_fraction must be between 0 and 1")
    cats = np.array(list(categorical_indices), dtype=int)
    numeric = np.array([j for j in range(X.shape[1]) if j not in set(cats)], dtype=int)
    rng = np.random.default_rng(seed)
    classes, counts = np.unique(y, return_counts=True)
    largest = int(counts.max())
    extra_x, extra_y, per_class = [], [], {}
    for label, count in zip(classes, counts):
        needed = largest - int(count)
        if needed == 0:
            continue
        minority = X[y == label]
        if len(minority) < 2:
            raise ValueError(f"class {label} needs >=2 members to synthesize examples")
        nn_minor = NearestNeighbors(n_neighbors=min(k + 1, len(minority))).fit(minority)
        neighbor_idx = nn_minor.kneighbors(minority, return_distance=False)
        # ADASYN seed difficulty = fraction of neighbors not in current class.
        nn_all = NearestNeighbors(n_neighbors=min(k + 1, len(X))).fit(X)
        nearest_all = nn_all.kneighbors(minority, return_distance=False)
        difficulty = np.mean(y[nearest_all[:, 1:]] != label, axis=1)
        if difficulty.sum() <= 0:
            difficulty = np.ones(len(minority), dtype=float)
        difficulty /= difficulty.sum()
        num_smote = needed if method == "smote" else 0 if method == "adasyn" else int(round(smote_fraction * needed))
        num_adasyn = needed - num_smote
        new = []
        for count_new, weights in ((num_smote, None), (num_adasyn, difficulty)):
            if count_new == 0:
                continue
            seeds = rng.choice(len(minority), size=count_new, replace=True, p=weights)
            for a in seeds:
                pool = neighbor_idx[a][neighbor_idx[a] != a]
                b = int(rng.choice(pool)) if len(pool) else int(a)
                lam = rng.uniform()
                item = minority[a].copy()
                item[numeric] = item[numeric] + lam * (minority[b, numeric] - item[numeric])
                if len(cats):
                    item[cats] = np.where(rng.random(len(cats)) < .5,
                                          minority[a, cats], minority[b, cats])
                new.append(item)
        extra_x.extend(new)
        extra_y.extend([int(label)] * needed)
        per_class[str(int(label))] = {"smote": num_smote, "adasyn": num_adasyn}
    if not extra_x:
        return X.copy(), y.copy(), {"synthetic": 0, "by_class": {}}
    Xa = np.concatenate((X, np.asarray(extra_x)), axis=0)
    ya = np.concatenate((y, np.asarray(extra_y)), axis=0)
    indices = rng.permutation(len(ya))
    return Xa[indices], ya[indices], {"synthetic": len(extra_y), "by_class": per_class}
