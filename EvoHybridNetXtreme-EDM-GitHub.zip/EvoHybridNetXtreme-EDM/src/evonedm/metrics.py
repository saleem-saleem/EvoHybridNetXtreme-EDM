import numpy as np
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, precision_recall_fscore_support,
    f1_score, matthews_corrcoef, roc_auc_score, average_precision_score, confusion_matrix)


def calculate_metrics(y_true, predicted, prob, risk_idx=None):
    y_true = np.asarray(y_true, dtype=int)
    predicted = np.asarray(predicted, dtype=int)
    prob = np.asarray(prob, dtype=float)
    classes = np.unique(y_true)
    if prob.ndim != 2 or prob.shape[0] != len(y_true):
        raise ValueError("Probability matrix must be (n_samples, n_classes)")
    if not set(np.unique(predicted)).issubset(set(range(prob.shape[1]))):
        raise ValueError("Predicted class outside probability columns")
    cm = confusion_matrix(y_true, predicted, labels=np.arange(prob.shape[1]))
    if int(cm.sum()) != len(y_true):
        raise AssertionError("Confusion matrix sum does not match test-set size")
    correct = int(np.trace(cm))
    out = {
        "n_test": int(len(y_true)), "n_correct": correct,
        "accuracy": float(correct / len(y_true)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, predicted)),
        "macro_precision": float(precision_recall_fscore_support(y_true, predicted, average="macro", zero_division=0)[0]),
        "macro_recall": float(precision_recall_fscore_support(y_true, predicted, average="macro", zero_division=0)[1]),
        "macro_f1": float(f1_score(y_true, predicted, average="macro", zero_division=0)),
        "mcc": float(matthews_corrcoef(y_true, predicted)),
    }
    if risk_idx is not None:
        if risk_idx < 0 or risk_idx >= prob.shape[1]:
            raise ValueError("risk_idx not in probability columns")
        out["at_risk_recall"] = float(precision_recall_fscore_support(
            y_true, predicted, labels=[risk_idx], zero_division=0)[1][0])
        out["at_risk_f1"] = float(precision_recall_fscore_support(
            y_true, predicted, labels=[risk_idx], zero_division=0)[2][0])
    try:
        if prob.shape[1] == 2:
            positive = risk_idx if risk_idx is not None else 1
            out["roc_auc"] = float(roc_auc_score((y_true == positive).astype(int), prob[:, positive]))
            out["pr_auc"] = float(average_precision_score((y_true == positive).astype(int), prob[:, positive]))
        else:
            out["roc_auc"] = float(roc_auc_score(y_true, prob, multi_class="ovr", average="macro"))
            out["pr_auc"] = float("nan")
    except ValueError:
        out["roc_auc"], out["pr_auc"] = float("nan"), float("nan")
    return out, cm
