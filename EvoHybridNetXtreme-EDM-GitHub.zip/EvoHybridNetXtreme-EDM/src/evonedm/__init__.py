"""EvoHybridNetXtreme-EDM: reproducible methods, not a claim to reproduce manuscript scores."""
__version__ = "0.1.0"
