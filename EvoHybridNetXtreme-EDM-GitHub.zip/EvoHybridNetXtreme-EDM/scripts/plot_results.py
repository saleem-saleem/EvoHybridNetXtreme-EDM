"""Plot ONLY computed CSV outputs. Usage: python scripts/plot_results.py results/d1_smoke"""
from pathlib import Path
import argparse
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def plot(directory):
    out = Path(directory)
    cm_file = out / "confusion_matrix.csv"
    if cm_file.exists():
        cm = pd.read_csv(cm_file).values
        fig, ax = plt.subplots(figsize=(5.5, 4.8))
        im = ax.imshow(cm, cmap="Blues")
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, f"{int(cm[i, j])}", ha="center", va="center")
        ax.set_xlabel("Predicted class index")
        ax.set_ylabel("True class index")
        ax.set_title("Held-out confusion matrix")
        fig.colorbar(im, ax=ax)
        fig.tight_layout()
        fig.savefig(out / "confusion_matrix.png", dpi=300)
        plt.close(fig)
    for filename, name_col, outname, title in [
        ("baseline_comparison.csv", "model", "baseline_macro_f1.png", "Held-out macro-F1: baselines"),
        ("ablation.csv", "variant", "ablation_macro_f1.png", "Held-out macro-F1: ablations"),
    ]:
        path = out / filename
        if not path.exists():
            continue
        df = pd.read_csv(path).dropna(subset=["macro_f1"])
        if df.empty:
            continue
        fig, ax = plt.subplots(figsize=(max(7, len(df)*.75), 4.4))
        ax.bar(df[name_col], df["macro_f1"])
        ax.set_ylabel("Macro-F1")
        ax.set_title(title)
        ax.set_ylim(0, 1)
        ax.tick_params(axis="x", labelrotation=60)
        fig.tight_layout()
        fig.savefig(out / outname, dpi=300)
        plt.close(fig)
    print("Saved available plots to", out.resolve())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory")
    plot(parser.parse_args().directory)
