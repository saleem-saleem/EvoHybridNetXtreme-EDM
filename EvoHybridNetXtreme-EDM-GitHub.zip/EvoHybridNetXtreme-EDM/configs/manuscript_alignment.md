# Manuscript-to-code validation checklist

Before asserting paper reproducibility, establish from training logs/source code:

- [ ] Confirm each dataset target, class mapping, sampling ratio and whether enrolled are included with graduates.
- [ ] Confirm feature availability at the intended early-warning time; avoid label proxies.
- [ ] Confirm correct `accuracy = correct_predictions / test_set_size` for D1–D6; export integers for every confusion matrix.
- [ ] Recompute precision/recall/F1/MCC from predictions, not manually selected percentages.
- [ ] Confirm categorical encoding and hybrid SMOTE–ADASYN implementation match methods exactly.
- [ ] Confirm nested leakage-free feature selection and score construction across each training/validation partition.
- [ ] Confirm exact names and values of base learner search spaces, calibration type, Bayesian weighting, RFE, DE and CNN-LSTM.
- [ ] Rerun full nested or outer repeated splits with valid confidence intervals.
- [ ] Include strong tabular baselines: CatBoost, LightGBM, tuned XGBoost with SMOTE, MLP, optional TabNet; equalize tuning budgets.
- [ ] Measure training time and sensitivity to feature order, cost of DE vs no-DE, and risk-score feature ablation.
- [ ] Review Table 18 reference-method matching: [76] and [81] appear mismatched in current draft.
- [ ] Harmonize the authorship/contributions and any declared grant with verifiable information.
- [ ] Make repository data provenance, seeds, version pins, splits and scripts public; exclude personal student data.

## Differences from current manuscript

* Bayesian weighting in the script uses a softmax of cross-validation accuracy. It must not be described as a Bayesian posterior without deriving and validating that probability model.
* Unlike unspecified SMOTE+ADASYN chaining, resampler uses category-preserving interpolation and boundary-weighted parent sampling. This is a reimplementation/variant.
* Stage-2 uses a heuristic recursive elimination with ordinary selection CV and no claimed unbiased fold-level metrics.
* The input feature order is arbitrary; CNN-LSTM here detects interactions in a pseudo-sequence, not time series.
* Standard model calibration on oversampled data may affect real-world probability calibration. Evaluate reliability on an untouched validation population at its real prevalence.
* Evaluation code computes genuine measured outputs and will not match any manuscript table unless the data, method and run actually produce that value.
