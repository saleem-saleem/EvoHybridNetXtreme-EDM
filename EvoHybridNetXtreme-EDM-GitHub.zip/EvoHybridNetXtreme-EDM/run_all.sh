#!/usr/bin/env bash
set -euo pipefail
evonedm --dataset d1 --output results/d1 --with-ablations
evonedm --dataset d2 --output results/d2 --with-ablations
# D3, D4, D5 need manually verified outcome definitions.
# D6 uses explicitly declared dropout vs rest grouping (enrolled counted as not dropout).
evonedm --dataset d6 --target-mode dropout-vs-rest --output results/d6 --with-ablations
