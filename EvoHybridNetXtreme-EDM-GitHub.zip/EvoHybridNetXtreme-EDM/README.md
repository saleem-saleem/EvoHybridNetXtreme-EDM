# EvoHybridNetXtreme-EDM

**Reproducible research implementation scaffold for an imbalance-aware, three-stage student-outcome classifier.**

The stages follow the structure described in `three-stage-24-10-26.docx`:

1. **Bayesian-EnsembleMaximus** — train-only preprocessing/feature screening, Optuna-TPE tuning, RF/XGBoost/SVM/LR/kNN, probability calibration, out-of-fold stacking and class-risk augmentation.
2. **AdaptiveFeatureMasterX** — train-only mixed SMOTE/ADASYN-inspired augmentation (categorical-safe interpolation), heuristic recursive feature elimination and selection of a conventional classifier by inner CV.
3. **EvoHybridNetXtreme** — a 1D-CNN + LSTM model over the reduced feature vector, with DE/rand/1/bin feature-mask search using validation accuracy (or optional macro-F1).

**IMPORTANT:** The numbers in the submitted manuscript are **not packaged as experimental results**. They require re-execution and validation. In particular, 84.5% accuracy on exactly 100 test examples cannot be a single-run classification accuracy. All output files here are calculated from actual predicted labels/probabilities and integer-valued confusion matrices. This code is an independent reference implementation, not proof that the original publication's exact method/results have been reproduced. Differences are itemized below.

## Setup

Use Python 3.10–3.12. CPU supported; optional GPU is not used in this deterministic reference runner.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -e '.[baselines,dev]'
```

For a minimal environment without optional XGBoost/LightGBM/CatBoost/TabNet:

```bash
pip install -e '.[dev]'
```

## Quick run: fully generated synthetic dataset

```bash
evonedm --dataset d1 --fast --output results/d1_smoke
pytest -q
```

This does **not** require downloading datasets. The smoke run is intentionally quick and should not be cited as a research benchmark.

## Full experiments

```bash
# Synthetic (not genuine student records):
evonedm --dataset d1 --output results/d1 --with-ablations
evonedm --dataset d2 --output results/d2 --with-ablations

# UCI 697: explicit grouping, enrolled class counted in non-dropout:
evonedm --dataset d6 --target-mode dropout-vs-rest --output results/d6_drop_vs_rest --with-ablations

# UCI 697 alternative: exclude 'Enrolled', changes n from 4424 to 3630:
evonedm --dataset d6 --target-mode dropout-vs-graduate --output results/d6_drop_vs_grad

# UCI 582: inspect classes first; choose the at-risk target by its exact label:
evonedm --dataset d3 --positive-label 'YOUR_AT_RISK_CLASS' --output results/d3

# UCI 856: explicitly define grade 0 (Fail) vs grades 1–7:
evonedm --dataset d5 --binary-positive-values '0' --output results/d5_fail_vs_other

# Or retain eight original grades and designate class 0 as the risk class
# (may require additional data / rare-class handling):
evonedm --dataset d5 --positive-label '0' --output results/d5_original_grades

# UCI 467: verify your study's dependent variable before running.
# UCI does not expose an unequivocal target in the standard API:
evonedm --dataset d4 --target-column YOUR_VERIFIED_OUTCOME_COLUMN \
    --binary-positive-values 'YOUR_AT_RISK_LABEL' --output results/d4
```

Do not assume the phrase “at-risk” always identifies the minority class. The original UCI 697 task has three outcomes (Dropout, Enrolled, Graduate). `dropout-vs-rest` groups Enrolled with Graduate, a modeling choice requiring justification. Five-class results, if claimed, require *separately documented* label mapping and code, not numerical fabrication.

### Custom CSV

```bash
evonedm --dataset local --csv data/my_approved_anonymized_data.csv \
 --target-column Outcome --positive-label Fail \
 --categorical-columns Gender,Course,Campus \
 --output results/local
```

Never upload identifiable student records or protected education records to public GitHub.

## Outputs

Every run creates:

- `dataset_manifest.json` — exact dataset, original class counts, target mapping, raw feature count, split indices, categorical configuration
- `run_config.json`, `environment.json` — all CLI settings and environment versions
- `test_predictions.csv` — held-out row ID, true/predicted classes and every class probability
- `confusion_matrix.csv` — integer counts; trace / total = reported accuracy
- `proposed_metrics.json` — measured accuracy, balanced accuracy, macro-F1, MCC, ROC-AUC, binary PR-AUC and class-specific metrics
- `baseline_comparison.csv` — comparison on common held-out rows
- `model_details.json` — feature masks/names, stacking weights, DE evaluations
- `ablation.csv` — component comparisons if `--with-ablations` is set

No result file is manually prefilled or generated with fabricated scores.

## Experimental safeguards and limitations

1. **Test partition** is created before all fitted operations. Neither calibration, feature screening, RFE nor DE uses the held-out test labels. The test is evaluated after model selection. To estimate variance, add independently predeclared repeated outer train/test splits and report all repeats; rerunning until scores look favorable is invalid.
2. **Risk feature** is generated from base-model out-of-fold predictions plus a cross-fitted logistic meta-learner. Base-model tuning occurs within each outer OOF fold. The OOF meta construction is an engineering implementation of stacking, not a formal proof of complete nested conditional independence. Stage-2 internal CV is used for feature/model selection, not an unbiased reported score. A stricter nested CV of the *entire three-stage pipeline* is appropriate for publication.
3. **Sampling** combines uniform minority interpolation (SMOTE-like) and ADASYN-like boundary-weighted generation. Numeric features are interpolated; nominal category values are sampled from actual minority parents. It is an explicit categorical-safe *variant*, not guaranteed equivalent to the paper's undocumented SMOTE+ADASYN implementation. Set `--categorical-columns` for numeric-coded categorical variables.
4. **Sequence caveat:** CNN–LSTM consumes static attributes as a pseudo-sequence. A fixed input order does not mean that the columns are temporal observations. Demonstrate results for permuted feature orders and compare with appropriate tabular baselines before making claims about temporal dependencies.
5. **Class risk and early warning:** A risk probability is only meaningful if the designated class corresponds to a justified outcome. UCI 697 includes semester-end outcomes and curriculum features; do not call its use *enrollment-time early prediction* unless features are restricted to the information available at that time.
6. **Relative computational budget:** By default the baselines have fixed or modest settings while the proposed system uses several optimization steps. Publication should compare methods with balanced tuning budgets and include execution time, uncertainty and a resource breakdown.
7. **Claimed novelty:** Standard TPE, stacking, SMOTE, ADASYN, RFE, CNN–LSTM, and DE are established; novelty depends on empirically demonstrated cross-stage risk augmentation and independent validated performance, not custom names.
8. **The current reference implementation is not identical to the manuscript:** It uses a mixed-data-safe synthetic sampler rather than undocumented standard calls, inner model-selection folds rather than the stated 5 × 3 repeated CV, simplified selected hyperparameter search spaces, no exact reported evidence/posterior formula, and a validation-holdout approach for DE. Align every setting with the real original code or revise the manuscript. The CLI defaults prioritize a functional reference pipeline, not paper score recreation.
9. **Binary metrics:** `pr_auc` is average precision of the explicitly specified at-risk class (not trapezoidal PR area). Multiclass PR-AUC is deliberately left undefined. Accuracy and every precision/recall/F1 value derive from actual predictions.
10. **Synthetic examples** are generated by `make_classification`, not actual academic records; D1/D2 support engineering/debugging rather than external validity.

## Citation and datasets

Please cite UCI dataset creators and comply with their license. Reference dataset pages:

- D3: https://archive.ics.uci.edu/dataset/582/student+performance+on+an+entrance+examination
- D4: https://archive.ics.uci.edu/dataset/467/student+academics+performance
- D5: https://archive.ics.uci.edu/dataset/856/higher+education+students+performance+evaluation
- D6: https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success

See `configs/manuscript_alignment.md` for the submission readiness checklist.

## Proposed GitHub description

> Reference implementation of Bayesian stacking, cross-fitted risk features, class-imbalance-aware feature selection, and DE-optimized CNN–LSTM for educational outcome classification, with audited held-out metrics.

## License

MIT license covers source code generated for this repository. Dataset and third-party software licenses remain with their respective owners.

## Figures from measured outputs

After a run, generate 300-dpi visualizations from its saved CSVs:

```bash
python scripts/plot_results.py results/d1_smoke
```

This produces a held-out confusion-matrix figure, and macro-F1 comparison/ablation bar charts where corresponding CSVs exist. The plotting script never supplies hand-entered result values.
