import numpy as np
import pytest
from evonedm.data import load_data, holdout_split
from evonedm.metrics import calculate_metrics
from evonedm.resampling import hybrid_resample
from evonedm.stages import CNNLSTM
import torch


def test_original_synthetic_split_is_stratified():
    d = load_data("d1")
    tr, te = holdout_split(d, 42)
    assert len(tr) == 400 and len(te) == 100
    assert not set(tr).intersection(te)
    assert set(np.unique(d.y)) == {0, 1}


def test_accuracy_reconciles_confusion_matrix():
    y = np.array([0,0,0,1,1,1])
    p = np.array([0,0,1,1,0,1])
    probabilities = np.column_stack([1-np.array([.1,.2,.7,.8,.3,.9]),
                                        np.array([.1,.2,.7,.8,.3,.9])])
    metrics, cm = calculate_metrics(y, p, probabilities, risk_idx=1)
    assert cm.sum() == 6
    assert cm.trace() == 4
    assert metrics["accuracy"] == pytest.approx(4/6)
    assert metrics["at_risk_recall"] == pytest.approx(2/3)


def test_hybrid_exact_balancing_and_categories():
    X = np.array([[.1, 1],[.2, 1],[.8, 2],[.9, 2],[.8, 2],[.7,2],[.6,2]], float)
    y = np.array([1,1,0,0,0,0,0])
    Xa, ya, report = hybrid_resample(X, y, method="hybrid", categorical_indices=[1], seed=9)
    assert np.bincount(ya).tolist() == [5,5]
    assert set(np.unique(Xa[:, 1])).issubset({1,2})
    assert report["synthetic"] == 3


def test_none_resampler_does_not_modify_data():
    X = np.arange(12).reshape(6,2).astype(float)
    y = np.array([0,0,0,0,1,1])
    A, b, info = hybrid_resample(X, y, method="none")
    np.testing.assert_allclose(A, X)
    np.testing.assert_array_equal(b, y)
    assert info["synthetic"] == 0


def test_cnn_lstm_handles_single_attribute():
    net = CNNLSTM(num_classes=2)
    z = net(torch.randn(4,1))
    assert z.shape == (4,2)


def test_csv_needs_explicit_target(tmp_path):
    f = tmp_path / "input.csv"
    f.write_text("a,b,outcome\n1,2,fail\n2,3,pass\n3,4,pass\n4,5,fail\n")
    with pytest.raises(ValueError, match="target-column"):
        load_data("test", csv_path=str(f))
